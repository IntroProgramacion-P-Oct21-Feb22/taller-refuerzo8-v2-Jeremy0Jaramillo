/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package taller8v2;

import java.util.Locale;
import java.util.Scanner;

/**
 *
 * @author fabri
 */
public class Taller8v2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);
        entrada.useLocale(Locale.US);

        String nombrecliente;
        String palabra;
        String cadena = "";
        int tipo;
        int computadora;
        int cedula;
        int cantidad;
        double precio;
        double descuento;
        double porcentaje = 0;
        double preciou = 0;
        double preciototal;
        double total = 0;
        boolean bandera = true;

        do {
            System.out.println("Ingrese su nombre");
            nombrecliente = entrada.nextLine();

            System.out.println("Ingrese su número de cédula");
            cedula = entrada.nextInt();

            System.out.println("Ingrese el tipo de cliente que es (Solo ingresar número 1-4)");
            tipo = entrada.nextInt();

            if (tipo == 1) {
                porcentaje = 1;
            } else {
                if (tipo == 2) {
                    porcentaje = 5;
                } else {
                    if (tipo == 3) {
                        porcentaje = 10;
                    } else {
                        if (tipo == 4) {
                            porcentaje = 15;
                        }
                    }
                }
            }

            System.out.println("Ingrese el tipo de computadora que desea comprar (Solo ingresar número 1-3)\n"
                    + "Computadora 1 = $1000\n" + "Computadora 2 = $1100\n" + "Computadora 3 = $900");
            computadora = entrada.nextInt();
//Lo convertí a text block y el warning me sugiere que lo convierta en string que es lo que ya tengo

            if (computadora == 1) {
                preciou = 1000;
            } else {
                if (computadora == 2) {
                    preciou = 1100;
                } else {
                    if (computadora == 3) {
                        preciou = 900;
                    }
                }
            }

            System.out.println("Ingrese la cantidad que desea comprar de este tipo de computadora");
            cantidad = entrada.nextInt();

            precio = cantidad * preciou;

            descuento = (precio) * porcentaje / 100;

            preciototal = precio - descuento;

            total = total + preciototal;

            cadena = cadena + "Cliente " + nombrecliente + ", con cédula " + cedula + " compra "
                    + cantidad + " computadoras con precio individual " + "$" + preciou +
                    ". Total a pagar " + preciototal + "\n";

            entrada.nextLine();

            System.out.println("-------------------------------------------------------------------");

            System.out.println("*Si desea puede continuar haciendo compras en el mismo"
                    + " proceso pero solo es permitido bajo los datos de otra persona.*" + "\n");
            System.out.println("Para terminar el proceso Ingrese si, para seguir comprando"
                    + " ingrese cualquier otro escrito. ");
            palabra = entrada.nextLine();
//Lo mismo de arriba pasó aquí. Tampoco conozco mucho de los text blocks.
            
            if (palabra.equals("si")) {
                bandera = false;
            }

        } while (bandera == true);

        System.out.println(cadena + "\n" + "Total venta de computadoras: $" + total);
    }

}
